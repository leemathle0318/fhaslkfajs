#pragma once
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <algorithm>

namespace obs {
// Fixed-layout shared memory. Only lock-free atomics cross the process boundary;
// no std::mutex, Objective-C pointers, vectors, or pointers to producer memory.
static_assert(std::atomic<uint64_t>::is_always_lock_free, "64-bit atomics required");
static_assert(std::atomic<uint32_t>::is_always_lock_free, "32-bit atomics required");
constexpr uint32_t BusMagic = 0x4f425332, BusVersion = 2, WriterLease = 0x80000000;
constexpr size_t AudioRate = 48000, AudioCapacity = AudioRate * 2;
struct alignas(64) VideoSlot {
    std::atomic<uint32_t> lease{0}, sequence{0}, surface{0}, generation{0};
    std::atomic<uint64_t> dueUS{0};
};
struct alignas(64) SharedMedia {
    std::atomic<uint32_t> magic{0};
    uint32_t version = BusVersion, bytes = sizeof(SharedMedia);
    std::atomic<uint32_t> enabled{0}, generation{0}, audioReady{0};
    std::atomic<uint64_t> heartbeatUS{0};
    std::array<VideoSlot, 3> video;
    std::array<std::atomic<uint64_t>, AudioCapacity> audio;

    void initialize() {
        for (auto &value : audio) value.store(0x7fc00000u, std::memory_order_relaxed); // NaN = empty
        magic.store(BusMagic, std::memory_order_release);
    }
    bool fresh(uint64_t nowUS) const {
        uint64_t stamp = heartbeatUS.load(std::memory_order_acquire);
        return magic.load(std::memory_order_acquire) == BusMagic && version == BusVersion &&
            bytes == sizeof(SharedMedia) && enabled.load(std::memory_order_acquire) &&
            // Producer may publish a newer host timestamp after the consumer
            // samples its clock but before this atomic load. Don't flicker to
            // real input for that tiny race; large/future clock errors fail.
            (stamp > nowUS ? stamp - nowUS <= 2500 : nowUS - stamp < 2000000);
    }
    void resetAudio() {
        audioReady.store(0, std::memory_order_release);
        for (auto &value : audio) value.store(0x7fc00000u, std::memory_order_relaxed);
    }
    void writeAudio(const float *input, size_t count, double time) {
        if (!input || !std::isfinite(time) || time < 0 || time > 1e10) return;
        int64_t start = int64_t(std::llround(time * AudioRate));
        size_t first = count > AudioCapacity ? count - AudioCapacity : 0;
        for (size_t i = first; i < count; ++i) {
            int64_t tag = start + int64_t(i);
            float value = std::isfinite(input[i]) ? input[i] : 0;
            uint32_t bits; std::memcpy(&bits, &value, sizeof(bits));
            audio[size_t(tag % AudioCapacity)].store((uint64_t(uint32_t(tag)) << 32) | bits,
                std::memory_order_release);
        }
        if (count) audioReady.store(1, std::memory_order_release);
    }
    bool sample(int64_t tag, float &out) const {
        if (tag < 0) return false;
        uint64_t packed = audio[size_t(tag % AudioCapacity)].load(std::memory_order_acquire);
        if (uint32_t(packed >> 32) != uint32_t(tag)) return false;
        uint32_t bits = uint32_t(packed); std::memcpy(&out, &bits, sizeof(out));
        return std::isfinite(out);
    }
    bool readAudio(float *out, size_t count, double time, double rate, uint64_t nowUS) const {
        if (!out || count > 8192 || !std::isfinite(time) || time < 0 || time > 1e10 ||
            !std::isfinite(rate) || rate < 8000 || rate > 192000) return false;
        std::fill(out, out + count, 0);
        if (std::fabs(time - double(nowUS) / 1000000) > 2) return false;
        uint32_t epoch = generation.load(std::memory_order_acquire);
        if (!fresh(nowUS) || !audioReady.load(std::memory_order_acquire)) return false;
        bool found = false;
        for (size_t i = 0; i < count; ++i) {
            double index = (time + double(i) / rate) * AudioRate;
            int64_t a = int64_t(std::floor(index)); float x, y;
            if (sample(a, x)) {
                out[i] = sample(a + 1, y) ? x + float(index - a) * (y - x) : x;
                found = true;
            }
        }
        if (!fresh(nowUS) || !audioReady.load(std::memory_order_acquire) ||
            generation.load(std::memory_order_acquire) != epoch) {
            std::fill(out, out + count, 0); return false;
        }
        return found;
    }
};
inline bool acquireWriter(VideoSlot &slot) {
    uint32_t expected = 0;
    return slot.lease.compare_exchange_strong(expected, WriterLease, std::memory_order_acq_rel);
}
inline bool acquireReader(VideoSlot &slot) {
    uint32_t value = slot.lease.load(std::memory_order_acquire);
    for (unsigned attempt = 0; attempt < 3; ++attempt) {
        if (value >= WriterLease - 1) return false;
        if (slot.lease.compare_exchange_weak(value, value + 1, std::memory_order_acq_rel)) return true;
    }
    return false;
}
inline void releaseWriter(VideoSlot &slot) { slot.lease.store(0, std::memory_order_release); }
inline void releaseReader(VideoSlot &slot) { slot.lease.fetch_sub(1, std::memory_order_release); }
inline uint64_t heartbeatState(uint32_t pid, double time) {
    return (uint64_t(pid) << 32) | uint32_t(uint64_t(time * 1000));
}
inline bool heartbeatFresh(uint64_t state, double time) {
    if (!state || !std::isfinite(time) || time < 0) return false;
    uint32_t age = uint32_t(uint64_t(time * 1000)) - uint32_t(state);
    return age < 3000;
}
}
