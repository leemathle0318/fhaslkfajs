# OBSBridge 0.2.7：音频缓冲检查与错误日志修正

## 本次真实错误

用户GitHub截图显示0.2.6的9组C++回归已通过；真实macOS CoreMedia音频测试在读取混音输出的AudioBufferList时断言中止（原测试line91，退出134）。最后build退出1只是任务汇总，不是另一个手机错误。旧测试没有打印OSStatus或当前组合，所以无法从截图确定是否为容量、样本布局、时间信息或其他CoreMedia错误；没有声称原因已实测定位。

## 实际修改

- 按CoreMedia接口契约先查询所需AudioBufferList大小，再在有界、16字节对齐的4096字节暂存区提取。所需容量超限直接返回错误，不按通道数盲猜、扩展越界或无限分配；数据通道仍限定最多8。
- 手机读取原生麦克风样本和测试读取混音样本使用同一两阶段提取接口。仅新增取缓冲/验证，不改已连通的OBS接收解码、共享协议、libSandy文件授权。
- 输出不能仅依据CreateReady返回0认定可用：交付前再实际提取并检查通道/长度。不能提取的混音样本释放，保留原手机麦克风并报告真实错误码。
- 测试先验证原始音频fixture可读，然后验证混音输出。每个组合自动打印CASE、SOURCE、BUILD、EXTRACT和具体OSStatus、所需大小、实际容量；不再让用户手动查错误码。
- CoreMedia运行测试单独列为“CoreMedia audio sample tests”，输出同步保存到日志并在失败产物中上传。保留pipefail和全部断言，失败仍阻止打包，没有跳过音频验收。

接口依据：[Apple GetAudioBufferList 文档](https://developer.apple.com/documentation/coremedia/cmsamplebuffergetaudiobufferlistwithretainedblockbuffer(_:bufferlistsizeneededout:bufferlistout:bufferlistsize:blockbufferallocator:blockbuffermemoryallocator:flags:blockbufferout:))与本机已读取SDK头文件。该容量处理修正不证明截图中的OSStatus就是ArrayTooSmall。

## 使用新构建（暂不需要手机操作）

1. 上传 `OBSBridge-source-0.2.7.zip` 原文件。
2. 将“GitHub工作流-0.2.7音频缓冲检查修正版.txt”的内容覆盖仓库根 `.github/workflows/build-deb.yml`。
3. 提交后开始新Actions运行，不重跑旧提交；旧0.2.6运行仍只会打印旧断言。ZIP内部工作流不会自动启用。
4. 必须先让CoreMedia运行测试与完整打包通过，再下载rootless deb升级手机。现在不要求改OBS参数、重装libSandy或用手机试错。
5. 若CoreMedia仍失败，步骤自身会显示CASE/SOURCE/BUILD/EXTRACT；直接发这一处截图，或 `OBSBridge-build-diagnostics` 内coremedia-audio-test.log，不用手动找系统错误码。单纯build退出1不能替代具体步骤日志。

## 保留功能与验证边界

保留0.2.6的视频缓存连续性、可调旋转、原生PCM混音、独立host游标和麦克风1.0+OBS0.70限幅。画面仍可在长时断流或失败时透传真实输入，不是隐私屏障；近期媒体缓存未加密，停止不保证安全擦除，仅在可信局域网使用。

本机Windows的C++回归和iOS arm64对象编译已执行。真实macOS CoreMedia运行、Theos链接/签名/arm64e及手机音画验收仍未通过；**这是带容量修正和真实错误报告的源码版本，不宣称这次GitHub一定通过或直播声音已经可用。** 具体记录见TEST_RESULTS.md。
