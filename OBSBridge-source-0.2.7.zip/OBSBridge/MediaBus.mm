#import "MediaBus.h"
#import "Shared.h"
#import "SandboxAccess.h"
#include "core/MappingStatus.hpp"
#include "core/VideoContinuity.hpp"
#include "core/NativePCM.hpp"
#import <CoreImage/CoreImage.h>
#import <CoreMedia/CoreMedia.h>
#include <notify.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <new>

namespace {
const char *names[] = {OB_BUS_NOTIFY, OB_MEDIA_HEARTBEAT, OB_MEDIA_HOOKS, OB_MEDIA_COUNTS,
    OB_MEDIA_MAPPING, "local.xiaoguai.obsbridge.v4.media.identity", OB_VIDEO_ROTATION_NOTIFY,
    OB_AUDIO_NOTIFY ".phase", OB_AUDIO_NOTIFY ".format", OB_AUDIO_NOTIFY ".layout", OB_AUDIO_NOTIFY ".timing"};
int tokens[] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
std::mutex notifications;
uint32_t channel(unsigned i, uint64_t *value, bool write) {
    std::lock_guard<std::mutex> lock(notifications);
    if (tokens[i] < 0) {
        uint32_t rc = notify_register_check(names[i], &tokens[i]);
        if (rc != NOTIFY_STATUS_OK) { tokens[i] = -1; return rc; }
    }
    return write ? notify_set_state(tokens[i], *value) : notify_get_state(tokens[i], value);
}
uint64_t get(unsigned i) { uint64_t value = 0; channel(i, &value, false); return value; }
uint32_t set(unsigned i, uint64_t value) { return channel(i, &value, true); }
std::mutex stateLock;
std::shared_ptr<OBMapping> producerMapping, mapping;
std::mutex snapshotLock;
obs::VideoContinuity continuity;
std::shared_ptr<OBVideoLease> snapshot;
obs::SharedMedia *producer;
obs::MappedMedia *producerFile;
CVPixelBufferRef videoBuffers[3]{};
uint32_t frameSequence = 0;
unsigned nextSlot = 0;
unsigned erasePending = 0;
uint64_t mappingID = 0;
double nextLookup = 0;
NSString *producerMessage = @"文件媒体缓存尚未初始化";
NSString *consumerMessage = @"尚未收到共享会话";
void producerNote(NSString *text) { std::lock_guard<std::mutex> lock(stateLock); producerMessage = text; }
void consumerNote(NSString *text, obs::MappingCode code, uint32_t detail) {
    consumerMessage = text; // under stateLock
    uint32_t rc = set(4, obs::mappingState(code, detail));
    if (rc != NOTIFY_STATUS_OK) NSLog(@"[OBSBridge] mapping diagnosis notify failed: %u", rc);
}
NSString *producerError(const char *operation, int code) {
    NSString *text = [NSString stringWithFormat:@"文件缓存 %s 失败 errno=%d，%@", operation, code,
        [NSString stringWithUTF8String:strerror(code)] ?: @"未知错误"];
    producerNote(text); NSLog(@"[OBSBridge] %@", text); return text;
}
}

double OBNow(void) { return CMTimeGetSeconds(CMClockGetTime(CMClockGetHostTimeClock())); }
NSString *OBBusCreate(void) {
    if (producer) return nil;
    // Build a new inode then rename. Never truncate an existing live mapping.
    char temporary[] = OB_BUS_FILE ".XXXXXX";
    int fd = mkstemp(temporary);
    if (fd < 0) return producerError("mkstemp", errno);
    if (fchmod(fd, 0660) || ftruncate(fd, sizeof(obs::MappedMedia))) {
        int code = errno; close(fd); unlink(temporary); return producerError("size/permissions", code);
    }
    void *base = mmap(nullptr, sizeof(obs::MappedMedia), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    int mapError = errno; close(fd);
    if (base == MAP_FAILED) { unlink(temporary); return producerError("mmap", mapError); }
    uint64_t cookie = 0; do { arc4random_buf(&cookie, sizeof(cookie)); } while (!cookie);
    auto *file = new (base) obs::MappedMedia;
    file->initialize(cookie);
    struct stat existing{};
    int exists = lstat(OB_BUS_FILE, &existing), statError = errno;
    if ((!exists && (!S_ISREG(existing.st_mode) || existing.st_uid != geteuid() || existing.st_nlink != 1)) ||
        (exists && statError != ENOENT)) {
        munmap(base, sizeof(obs::MappedMedia)); unlink(temporary);
        return producerError("existing path validation", exists ? statError : EPERM);
    }
    if (rename(temporary, OB_BUS_FILE)) {
        int code = errno; munmap(base, sizeof(obs::MappedMedia)); unlink(temporary); return producerError("rename", code);
    }
    producerMapping = std::make_shared<OBMapping>(file); producerFile = file; producer = &file->state;
    OBBusHeartbeat();
    uint32_t rc = set(0, cookie);
    if (rc != NOTIFY_STATUS_OK) {
        producerNote([NSString stringWithFormat:@"文件缓存已建立，但会话通知写入失败 rc=%u", rc]);
        return OBBusProducerStatus();
    }
    producerNote(@"文件媒体缓存已发布");
    return nil;
}
void OBBusHeartbeat(void) {
    if (producer) producer->heartbeatUS.store(uint64_t(OBNow()*1000000), std::memory_order_release);
}
void OBBusEnable(BOOL enabled) {
    if (!producer) return;
    if (!enabled && !producer->enabled.load(std::memory_order_acquire)) {
        // Retry only slots that were leased during stop. No secure erase claim:
        // clearing the live mapping cannot remove old filesystem snapshots.
        for (unsigned i = 0; i < 3; ++i) if ((erasePending & (1u << i)) && obs::acquireWriter(producer->video[i])) {
            obs::beginFrameWrite(producer->video[i]);
            auto &raw = producerFile->frames[i];
            raw.clear();
            erasePending &= ~(1u << i); obs::releaseWriter(producer->video[i]);
        }
        return;
    }
    producer->enabled.store(0, std::memory_order_release);
    producer->generation.fetch_add(1, std::memory_order_acq_rel); producer->resetAudio();
    erasePending = enabled ? 0 : 7;
    for (unsigned i = 0; i < 3; ++i) {
        auto &slot = producer->video[i];
        if (!obs::acquireWriter(slot)) continue;
        obs::beginFrameWrite(slot); slot.dueUS.store(0, std::memory_order_relaxed);
        if (!enabled) {
            auto &raw = producerFile->frames[i];
            raw.clear(); erasePending &= ~(1u << i);
        }
        obs::releaseWriter(slot);
    }
    OBBusHeartbeat(); producer->enabled.store(enabled, std::memory_order_release);
}
void OBBusResetAudio(void) {
    if (producer) { producer->generation.fetch_add(1, std::memory_order_acq_rel); producer->resetAudio(); }
}
void OBBusWriteAudio(const float *samples, size_t count, double due) {
    if (producer && producer->enabled.load(std::memory_order_acquire)) producer->writeAudio(samples, count, due);
}
BOOL OBBusPublishVideo(CVPixelBufferRef source, double due) {
    if (!producer || !source || !producer->enabled.load(std::memory_order_acquire)) return NO;
    unsigned chosen = 3;
    for (unsigned attempt = 0; attempt < 3; ++attempt) {
        unsigned i = (nextSlot + attempt) % 3;
        if (obs::acquireWriter(producer->video[i])) { chosen = i; break; }
    }
    if (chosen == 3) return NO;
    auto &slot = producer->video[chosen];
    obs::beginFrameWrite(slot); // invalidate before changing atomic payload
    BOOL ok = NO;
    @try {
        double inputW = CVPixelBufferGetWidth(source), inputH = CVPixelBufferGetHeight(source);
        if (inputW > 0 && inputH > 0) {
            double scale = std::min(1., std::min(1280. / std::max(inputW, inputH),
                std::sqrt(double(obs::MaximumPixels)/(inputW*inputH))));
            size_t w = std::max(size_t(2), size_t(inputW*scale) & ~size_t(1));
            size_t h = std::max(size_t(2), size_t(inputH*scale) & ~size_t(1));
            CVPixelBufferRef &pixel = videoBuffers[chosen];
            if (pixel && (CVPixelBufferGetWidth(pixel) != w || CVPixelBufferGetHeight(pixel) != h)) {
                CVPixelBufferRelease(pixel); pixel = nullptr;
            }
            if (!pixel) {
                NSDictionary *attrs = @{(id)kCVPixelBufferIOSurfacePropertiesKey: @{}};
                CVReturn rc = CVPixelBufferCreate(kCFAllocatorDefault, w, h, kCVPixelFormatType_32BGRA,
                    (__bridge CFDictionaryRef)attrs, &pixel);
                if (rc != kCVReturnSuccess) producerNote([NSString stringWithFormat:@"本机 BGRA 缓冲创建失败 rc=%d", rc]);
            }
            if (pixel) {
                static CIContext *context; static dispatch_once_t once;
                dispatch_once(&once, ^{ context = [CIContext contextWithOptions:@{kCIContextUseSoftwareRenderer: @NO}]; });
                CIImage *image = [CIImage imageWithCVPixelBuffer:source];
                image = [image imageByApplyingTransform:CGAffineTransformMakeScale(double(w)/inputW, double(h)/inputH)];
                [context render:image toCVPixelBuffer:pixel];
                CVReturn lockRC = CVPixelBufferLockBaseAddress(pixel, kCVPixelBufferLock_ReadOnly);
                if (lockRC == kCVReturnSuccess) {
                    auto &raw = producerFile->frames[chosen];
                    ok = raw.write(static_cast<const uint8_t *>(CVPixelBufferGetBaseAddress(pixel)),
                        CVPixelBufferGetBytesPerRow(pixel), uint32_t(w), uint32_t(h));
                    CVPixelBufferUnlockBaseAddress(pixel, kCVPixelBufferLock_ReadOnly);
                    if (ok) {
                        slot.surface.store(chosen + 1, std::memory_order_relaxed); // slot tag, not an IOSurface ID
                        slot.generation.store(producer->generation.load(std::memory_order_acquire), std::memory_order_relaxed);
                        slot.dueUS.store(uint64_t(due*1000000), std::memory_order_relaxed);
                        if (++frameSequence == 0) ++frameSequence;
                        slot.sequence.store(frameSequence, std::memory_order_release); nextSlot = (chosen+1)%3;
                    }
                } else producerNote([NSString stringWithFormat:@"本机 BGRA 读取失败 rc=%d", lockRC]);
            }
        }
    } @catch (NSException *exception) { producerNote([@"文件视频发布异常：" stringByAppendingString:exception.name]); }
    if (!ok) slot.sequence.store(0, std::memory_order_release);
    obs::releaseWriter(slot); return ok;
}
NSString *OBBusProducerStatus(void) { std::lock_guard<std::mutex> lock(stateLock); return producerMessage; }
uint64_t OBBusSession(void) { return get(0); }
void OBBusSetVideoRotation(unsigned turns) {
    uint32_t rc = set(6, turns & 3);
    if (rc) NSLog(@"[OBSBridge] video rotation notify failed rc=%u", rc);
}
unsigned OBBusVideoRotation(void) { return unsigned(get(6) & 3); }
void OBBusClearVideoSnapshot(void) {
    std::lock_guard<std::mutex> lock(snapshotLock);
    continuity.clear(); snapshot.reset();
}
std::shared_ptr<OBMapping> OBBusConsumer(void) {
    std::lock_guard<std::mutex> lock(stateLock);
    double now = OBNow();
    if (now >= nextLookup) {
        nextLookup = now + .25;
        uint64_t session = 0; uint32_t rc = channel(0, &session, false);
        if (rc != NOTIFY_STATUS_OK || !session) {
            mapping.reset(); mappingID = 0;
            consumerNote(@"未收到共享会话或通知读取失败", rc ? obs::MappingCode::Notification : obs::MappingCode::MissingID, rc);
        } else if (session != mappingID || !mapping) {
            mapping.reset(); mappingID = 0;
            int fd = open(OB_BUS_FILE, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
            if (fd < 0) consumerNote(@"文件缓存 open 失败", obs::MappingCode::FileOpen, uint32_t(errno));
            else {
                struct stat info{};
                obs::MappingCode code = obs::MappingCode::Ready; uint32_t detail = uint32_t(session);
                if (fstat(fd, &info)) { code = obs::MappingCode::FileStat; detail = uint32_t(errno); }
                else if (!S_ISREG(info.st_mode) || info.st_nlink != 1 || (info.st_mode & S_IWOTH) ||
                    (info.st_uid != 0 && info.st_uid != 501 && info.st_uid != geteuid())) code = obs::MappingCode::FilePermissions;
                else if (info.st_size != off_t(sizeof(obs::MappedMedia))) {
                    code = obs::MappingCode::AllocationSize; detail = uint32_t(info.st_size);
                }
                if (code != obs::MappingCode::Ready) {
                    close(fd); consumerNote(@"文件缓存元数据校验失败", code, detail);
                } else {
                    void *base = mmap(nullptr, sizeof(obs::MappedMedia), PROT_READ, MAP_SHARED, fd, 0);
                    int mapError = errno; close(fd);
                    if (base == MAP_FAILED) consumerNote(@"文件缓存 mmap 失败", obs::MappingCode::FileMap, uint32_t(mapError));
                    else {
                        auto *file = static_cast<obs::MappedMedia *>(base);
                        if (!file->valid(session)) {
                            munmap(base, sizeof(obs::MappedMedia)); consumerNote(@"文件会话/协议尚不匹配", obs::MappingCode::Cookie, 0);
                        } else {
                            mapping = std::make_shared<OBMapping>(file); mappingID = session;
                            consumerNote(@"只读文件媒体缓存映射成功", obs::MappingCode::Ready, uint32_t(session));
                        }
                    }
                }
            }
        }
    }
    return mapping;
}
NSString *OBBusConsumerError(void) { std::lock_guard<std::mutex> lock(stateLock); return consumerMessage; }
std::unique_ptr<OBVideoLease> OBBusCopyVideo(void) {
    auto current = OBBusConsumer();
    std::lock_guard<std::mutex> lock(snapshotLock);
    uint64_t now = uint64_t(OBNow()*1000000);
    uint32_t epoch = current ? current->data->generation.load(std::memory_order_acquire) : 0;
    bool active = current && current->data->fresh(now);
    continuity.context(current ? current->memory->cookie : 0, epoch, active);
    if (!continuity.valid) snapshot.reset();
    if (!active) return nullptr;
    auto reuse = [&]() -> std::unique_ptr<OBVideoLease> {
        uint64_t time = uint64_t(OBNow()*1000000);
        bool stillActive = current->data->fresh(time) &&
            current->data->generation.load(std::memory_order_acquire) == epoch;
        if (!stillActive || !snapshot || !continuity.reusable(time)) {
            continuity.clear(); snapshot.reset(); return nullptr;
        }
        return std::make_unique<OBVideoLease>(current, CVPixelBufferRetain(snapshot->pixel));
    };
    std::array<obs::FrameTicket, 3> candidates{}; size_t count = 0;
    for (unsigned i = 0; i < 3; ++i) {
        obs::FrameTicket candidate{};
        if (obs::captureFrame(*current->memory, i, now, candidate)) candidates[count++] = candidate;
    }
    std::sort(candidates.begin(), candidates.begin() + count,
        [](const obs::FrameTicket &a, const obs::FrameTicket &b) { return a.due > b.due; });
    NSDictionary *attrs = @{(id)kCVPixelBufferIOSurfacePropertiesKey: @{}};
    for (size_t i = 0; i < count; ++i) {
        const auto &candidate = candidates[i];
        if (continuity.same(candidate.slot, candidate.sequence)) return reuse();
        CVPixelBufferRef pixel = nullptr;
        CVReturn rc = CVPixelBufferCreate(kCFAllocatorDefault, candidate.geometry.width, candidate.geometry.height,
            kCVPixelFormatType_32BGRA, (__bridge CFDictionaryRef)attrs, &pixel);
        bool copied = false;
        if (rc == kCVReturnSuccess && pixel && CVPixelBufferLockBaseAddress(pixel, 0) == kCVReturnSuccess) {
            copied = obs::copyFrameTimed(*current->memory, candidate, [] { return uint64_t(OBNow()*1000000); },
                static_cast<uint8_t *>(CVPixelBufferGetBaseAddress(pixel)),
                CVPixelBufferGetBytesPerRow(pixel), CVPixelBufferGetDataSize(pixel));
            CVPixelBufferUnlockBaseAddress(pixel, 0);
        }
        if (copied && continuity.accept(candidate.slot, candidate.sequence, candidate.due, uint64_t(OBNow()*1000000))) {
            snapshot = std::make_shared<OBVideoLease>(current, pixel);
            return reuse();
        }
        if (pixel) CVPixelBufferRelease(pixel);
    }
    // Slot overwritten during copy? Keep the last validated private snapshot,
    // not one frame of the real camera. A stale/disabled stream still invalidates.
    return reuse();
}
void OBMediaHeartbeat(uint32_t hooks, uint64_t videoCalls, uint64_t audioCalls,
                      uint64_t replaced, uint64_t mixed, uint32_t failure) {
    // This health channel does not depend on writing a preferences file.
    uint32_t rc = set(1, obs::heartbeatState(uint32_t(getpid()), OBNow()));
    rc |= set(2, (uint64_t(hooks & 255) << 56) | (uint64_t(failure & 255) << 48) |
        (uint64_t(uint32_t(videoCalls) & 0xffffff) << 24) | (uint32_t(audioCalls) & 0xffffff));
    rc |= set(5, (uint64_t(geteuid()) << 32) | getegid());
    rc |= set(3, (uint64_t(uint32_t(replaced)) << 32) | uint32_t(mixed));
    if (rc != NOTIFY_STATUS_OK) {
        static uint32_t last = UINT32_MAX;
        if (rc != last) { NSLog(@"[OBSBridge] media health notify failed: %u", rc); last = rc; }
    }
}
NSString *OBMediaStatus(void) {
    uint64_t heartbeat = 0;
    uint32_t rc = channel(1, &heartbeat, false);
    if (rc != NOTIFY_STATUS_OK)
        return [NSString stringWithFormat:@"媒体心跳通知读取失败：%u，尚不能判断模块是否加载", rc];
    uint64_t hooks = get(2), counts = get(3);
    if (!obs::heartbeatFresh(heartbeat, OBNow()))
        return @"媒体模块：未收到新心跳（未加载、已停止或通知通道受限；需加载日志，不能据此认定某一种原因）";
    unsigned failure = unsigned((hooks >> 48) & 255);
    NSString *reason = failure == 0 ? @"无报告错误" : failure == 1 ? @"未看到兼容的 BWNodeOutput 接口" :
        failure == 2 ? @"文件媒体缓存映射失败" : failure == 3 ? @"没有可用共享视频帧/视频映射失败" :
        failure == 4 ? @"画面格式或渲染失败" : failure == 5 ? @"音频格式不支持/缺 OBS 音频" : @"未知";
    uint64_t map = 0;
    uint32_t mapRC = channel(4, &map, false), detail = obs::mappingDetail(map);
    NSString *mapText;
    if (mapRC != NOTIFY_STATUS_OK) mapText = [NSString stringWithFormat:@"映射诊断读取失败 rc=%u", mapRC];
    else switch (obs::mappingCode(map)) {
        case obs::MappingCode::Unreported: mapText = @"尚无映射诊断（检查两模块是否均为 0.2.7）"; break;
        case obs::MappingCode::MissingID: mapText = @"未收到共享会话"; break;
        case obs::MappingCode::LookupFailed: mapText = @"旧协议状态，不应出现在本版"; break;
        case obs::MappingCode::MissingBase: mapText = @"缓存基地址为空"; break;
        case obs::MappingCode::Alignment: mapText = [NSString stringWithFormat:@"基地址未对齐，余数=%u", detail]; break;
        case obs::MappingCode::AllocationSize: mapText = [NSString stringWithFormat:@"分配大小不符：%u 字节", detail]; break;
        case obs::MappingCode::Magic: mapText = [NSString stringWithFormat:@"协议标记不符：0x%08x", detail]; break;
        case obs::MappingCode::Version: mapText = [NSString stringWithFormat:@"共享协议版本不符：%u", detail]; break;
        case obs::MappingCode::ProtocolSize: mapText = [NSString stringWithFormat:@"协议大小不符：%u 字节", detail]; break;
        case obs::MappingCode::Notification: mapText = [NSString stringWithFormat:@"共享 ID 通知读取失败 rc=%u", detail]; break;
        case obs::MappingCode::Ready: mapText = [NSString stringWithFormat:@"只读文件映射成功，会话=%u", detail]; break;
        case obs::MappingCode::FileOpen: mapText = [NSString stringWithFormat:@"open(RO) 失败 errno=%u", detail]; break;
        case obs::MappingCode::FileStat: mapText = [NSString stringWithFormat:@"fstat 失败 errno=%u", detail]; break;
        case obs::MappingCode::FileMap: mapText = [NSString stringWithFormat:@"mmap 失败 errno=%u", detail]; break;
        case obs::MappingCode::FilePermissions: mapText = @"缓存文件属主/类型/权限不安全，拒绝映射"; break;
        case obs::MappingCode::Cookie: mapText = @"会话不同，等待新文件/通知一致"; break;
        default: mapText = [NSString stringWithFormat:@"未知映射诊断 code=%u detail=%u", uint32_t(obs::mappingCode(map)), detail]; break;
    }
    uint64_t identity = get(5);
    return [NSString stringWithFormat:@"媒体模块：心跳正常，PID %u，UID %u/GID %u\n输出节点 %u；视频回调 %llu / 音频回调 %llu\n实际替换 %llu / 实际混音 %llu\n最近媒体结果：%@\n映射检查：%@\n%@\n%@",
        uint32_t(heartbeat >> 32), uint32_t(identity >> 32), uint32_t(identity), unsigned(hooks >> 56),
        (unsigned long long)((hooks >> 24) & 0xffffff), (unsigned long long)(hooks & 0xffffff),
        (unsigned long long)(counts >> 32), (unsigned long long)uint32_t(counts), reason, mapText, OBMediaReadAccessStatus(), OBMediaAudioStatus()];
}
void OBMediaAudioState(uint64_t phase, uint64_t format, uint64_t layout, uint64_t timing) {
    uint32_t rc = set(8, format); rc |= set(9, layout); rc |= set(10, timing); rc |= set(7, phase);
    if (rc) NSLog(@"[OBSBridge] audio metadata notify failed rc=%u", rc);
}
NSString *OBMediaAudioStatus(void) {
    if (!obs::heartbeatFresh(get(1), OBNow())) return @"音频：没有新媒体心跳，不能用旧音频诊断判断当前运行状态";
    uint64_t state = get(7), format = get(8), layout = get(9), timing = get(10);
    auto phase = obs::AudioPhase(state >> 32); NSString *text;
    switch (phase) {
        case obs::AudioPhase::None: text = @"尚未记录混音尝试"; break;
        case obs::AudioPhase::Inactive: text = @"尚未启用/共享数据不可用"; break;
        case obs::AudioPhase::Format: text = @"样本不是支持的原生 PCM，保留麦克风"; break;
        case obs::AudioPhase::FrameCount: text = @"音频帧数不支持"; break;
        case obs::AudioPhase::NotReady: text = @"原音频数据尚未就绪"; break;
        case obs::AudioPhase::BufferList: text = @"提取音频缓冲失败"; break;
        case obs::AudioPhase::Layout: text = @"PCM 格式/通道布局不支持或越界"; break;
        case obs::AudioPhase::Busy: text = @"同节点并发，保留本次麦克风"; break;
        case obs::AudioPhase::Underflow: text = @"对应播放时刻没有 OBS PCM"; break;
        case obs::AudioPhase::Build: text = @"构造混音输出失败"; break;
        case obs::AudioPhase::Mixed: text = @"已生成 OBS + 手机麦克风混音样本"; break;
        case obs::AudioPhase::AlreadyMixed: text = @"已混音，避免重复叠加"; break;
        default: text = @"未知音频状态"; break;
    }
    uint32_t id = uint32_t(format >> 32); char fourcc[5]{};
    for (unsigned i = 0; i < 4; ++i) {
        unsigned c = (id >> (24 - i * 8)) & 255; fourcc[i] = c >= 32 && c <= 126 ? char(c) : '?';
    }
    return [NSString stringWithFormat:@"音频：%@，code=%d\n原生 %s / %u Hz / %u 位 / %u 通道\nflags=0x%08x；stride=%u；buffers=%u；frames=%u",
        text, int32_t(uint32_t(state)), fourcc, uint32_t(timing >> 32), unsigned(layout >> 48),
        unsigned((layout >> 40) & 255), uint32_t(format), uint32_t(layout),
        unsigned((layout >> 32) & 255), uint32_t(timing)];
}
