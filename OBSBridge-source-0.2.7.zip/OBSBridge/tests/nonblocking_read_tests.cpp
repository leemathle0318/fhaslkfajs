#include "../core/NonblockingRead.hpp"
#include "../core/MappingStatus.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <limits>
#include <thread>
#include <vector>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
using Socket = SOCKET;
constexpr Socket Invalid = INVALID_SOCKET;
static void closeSocket(Socket s) { closesocket(s); }
static int socketError() { return WSAGetLastError(); }
static bool wouldBlock(int code) { return code == WSAEWOULDBLOCK; }
static bool interrupted(int code) { return code == WSAEINTR; }
static bool nonblocking(Socket s) { u_long enabled = 1; return ioctlsocket(s, FIONBIO, &enabled) == 0; }
#else
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
using Socket = int;
constexpr Socket Invalid = -1;
static void closeSocket(Socket s) { close(s); }
static int socketError() { return errno; }
static bool wouldBlock(int code) { return code == EAGAIN || code == EWOULDBLOCK; }
static bool interrupted(int code) { return code == EINTR; }
static bool nonblocking(Socket s) {
    int flags = fcntl(s, F_GETFL, 0);
    return flags >= 0 && fcntl(s, F_SETFL, flags | O_NONBLOCK) == 0;
}
#endif
static double now() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
static void policyTests() {
    using namespace obs;
    int calls = 0, waits = 0;
    auto active = [] { return true; };
    auto clock = [] { return 1.; };
    auto wait = [&] { ++waits; };
    auto data = nonblockingRead(active, [&] {
        ++calls;
        return calls == 1 ? ReadAttempt{-1,EINTR,true,false} :
            calls == 2 ? ReadAttempt{-1,EAGAIN,false,true} : ReadAttempt{7,0,false,false};
    }, clock, wait, 0.);
    assert(data.end == ReadEnd::Data && data.bytes == 7 && waits == 1 && calls == 3);
    calls = waits = 0;
    auto permission = nonblockingRead(active, [&] { ++calls; return ReadAttempt{-1,EPERM,false,false}; }, clock, wait, 0.);
    assert(permission.end == ReadEnd::Error && permission.error == EPERM && calls == 1 && waits == 0);
    auto eof = nonblockingRead(active, [] { return ReadAttempt{0,0,false,false}; }, clock, wait, 0.);
    assert(eof.end == ReadEnd::Eof);
    auto idle = [] { return ReadAttempt{-1,EAGAIN,false,true}; };
    auto timeout = nonblockingRead(active, idle, [] { return 9.; }, wait, 0.);
    assert(timeout.end == ReadEnd::Timeout && waits == 0);
    auto badClock = nonblockingRead(active, idle, [] { return std::numeric_limits<double>::quiet_NaN(); }, wait, 0.);
    assert(badClock.end == ReadEnd::Timeout);
    auto cancelled = nonblockingRead([] { return false; }, [&] { ++calls; return ReadAttempt{1,0,false,false}; }, clock, wait, 0.);
    assert(cancelled.end == ReadEnd::Cancelled && calls == 1);
    bool running = true;
    auto cancelledWaiting = nonblockingRead([&] { return running; }, idle, clock, [&] { running = false; }, 0.);
    assert(cancelledWaiting.end == ReadEnd::Cancelled);
    auto backwards = nonblockingRead(active, idle, [] { return -1.; }, wait, 0.);
    assert(backwards.end == ReadEnd::Timeout);
    for (uint32_t code = 0; code <= uint32_t(MappingCode::Cookie); ++code)
        for (uint32_t detail : {0u, 1u, 0xffffffffu}) {
            uint64_t state = mappingState(MappingCode(code), detail);
            assert(uint32_t(mappingCode(state)) == code && mappingDetail(state) == detail);
        }
    std::puts("PASS: read retry/timeout/cancellation/EPERM policy; mapping diagnostic encoding");
}
static void tcpTest() {
#ifdef _WIN32
    WSADATA data{}; assert(WSAStartup(MAKEWORD(2,2), &data) == 0);
#endif
    Socket listener = socket(AF_INET, SOCK_STREAM, 0); assert(listener != Invalid);
    sockaddr_in address{}; address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    assert(bind(listener, reinterpret_cast<sockaddr *>(&address), sizeof(address)) == 0);
    assert(listen(listener, 1) == 0);
#ifdef _WIN32
    int length = sizeof(address);
#else
    socklen_t length = sizeof(address);
#endif
    assert(getsockname(listener, reinterpret_cast<sockaddr *>(&address), &length) == 0);
    std::vector<char> expected(65537);
    for (size_t i = 0; i < expected.size(); ++i) expected[i] = char((i * 13 + 7) % 251);
    Socket client = socket(AF_INET, SOCK_STREAM, 0); assert(client != Invalid);
    assert(connect(client, reinterpret_cast<sockaddr *>(&address), sizeof(address)) == 0);
    Socket receiver = accept(listener, nullptr, nullptr); assert(receiver != Invalid);
    assert(nonblocking(receiver));
    char buffer[211];
    int initial = int(recv(receiver, buffer, sizeof(buffer), 0));
    assert(initial < 0 && wouldBlock(socketError()));
    std::thread writer([&] {
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        for (size_t offset = 0; offset < expected.size();) {
            size_t count = expected.size() - offset; if (count > 137) count = 137;
            int sent = int(send(client, expected.data()+offset, int(count), 0));
            assert(sent > 0); offset += size_t(sent);
            if (offset % 1024 < 137) std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        closeSocket(client);
    });
    std::vector<char> actual;
    double lastData = now(); int waits = 0;
    while (true) {
        auto result = obs::nonblockingRead([] { return true; }, [&] {
            int n = int(recv(receiver, buffer, sizeof(buffer), 0));
            int code = n < 0 ? socketError() : 0;
            return obs::ReadAttempt{n, code, interrupted(code), wouldBlock(code)};
        }, now, [&] { ++waits; std::this_thread::sleep_for(std::chrono::milliseconds(10)); }, lastData, 2.);
        if (result.end == obs::ReadEnd::Eof) break;
        assert(result.end == obs::ReadEnd::Data);
        actual.insert(actual.end(), buffer, buffer + result.bytes); lastData = now();
    }
    writer.join(); closeSocket(receiver); closeSocket(listener);
    assert(actual == expected && waits > 0);
#ifdef _WIN32
    WSACleanup();
#endif
    std::puts("PASS: actual loopback nonblocking recv, partial packets, 65537 bytes and EOF (not an iPhone test)");
}
int main() { policyTests(); tcpTest(); }
