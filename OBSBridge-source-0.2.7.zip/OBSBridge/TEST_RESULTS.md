# 0.2.7 检查记录（2026-10-12）

## 外部实际失败证据

0.2.6在用户GitHub macOS构建中，9组纯C++回归全部通过，但CoreMedia测试读取混音AudioBufferList断言失败/退出134，未生成可交付deb。旧断言没有打印错误码，不能认定为某个具体CoreMedia错误。不是手机验证失败或成功记录。

## 本机执行

- 从0.2.7源码重新编译并运行9组C++测试：timeline、shortcut、shared_media、nonblocking_read、pending_frames、mapped_media、access_attempt、video_continuity、native_audio；全部通过。
- 44种原生PCM布局/位深/端序组合与独立已知编码字节、8.24/Float64/24位填充、越界/限幅/NaN；合成880Hz麦克风与440Hz OBS混合、游标抖动/重置回归。不是手机采样。
- 5000并发帧版本、两Windows进程只读共享BGRA/PCM及视频缓存/旋转策略回归通过；传输协议与已通解码、授权保持不变。
- 最终12个插件单元及CoreMedia测试源文件，共13个iOS arm64 Mach-O对象编译；SDK16.5/deploy15/ARC/blocks/Wall/Wextra/Werror。不是完整链接或实际框架运行。
- 16项源码结构检查、5项打包准备测试、12项不可安装的合成deb检查；ZIP完整性/LF/版本/源码一致、YAML/Bash/嵌入Python与10种定位/旧源码/换行/危险路径案例检查。

## 未完成

Windows没有macOS CoreMedia运行库，不能运行此次失败API；新两阶段提取/输出自验证/日志用例只通过对象编译。Actions中的真实API测试保留，失败不会被忽略。没有完整GitHub构建、签名/arm64e、手机稳定性/方向/混音、观众端或音画同步通过记录。

0.2.7修容量契约与观测缺口，未把“猜测容量问题”写成“已重现并修复”的事实。若仍失败，自动记录的OSStatus和具体CASE/SOURCE/BUILD/EXTRACT将进一步区分fixture/输出构造/提取阶段。
