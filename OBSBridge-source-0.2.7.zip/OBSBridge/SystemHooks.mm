#import "Receiver.h"
#import "MediaBus.h"
#import "Shared.h"
#import "SandboxAccess.h"
#import <objc/runtime.h>
#import <substrate.h>
#include <mach-o/dyld.h>
#include <atomic>
#include <array>
#include <algorithm>
#include <utility>
#include <cstring>

namespace {
using Emit = void (*)(id, SEL, CMSampleBufferRef);
struct Hook { Class cls = Nil; std::atomic<Emit> original{nullptr}; };
constexpr unsigned MaximumHooks = 32;
std::array<Hook, MaximumHooks> hooks;
std::atomic<unsigned> hookCount{0};
std::atomic<uint64_t> videoCalls{0}, audioCalls{0}, replaced{0}, mixed{0};
std::atomic<uint32_t> failure{1};
dispatch_queue_t checkQueue;
dispatch_source_t healthTimer;
std::atomic<bool> queued{false};
thread_local unsigned depth = 0;

template<size_t Slot> void emit(id self, SEL cmd, CMSampleBufferRef sample) {
    Emit original = hooks[Slot].original.load(std::memory_order_acquire);
    if (!original) return;
    if (depth || !sample) { original(self, cmd, sample); return; }
    ++depth;
    @try {
        @autoreleasepool {
            auto format = CMSampleBufferGetFormatDescription(sample);
            OSType type = format ? CMFormatDescriptionGetMediaType(format) : 0;
            if (type == kCMMediaType_Video && CMSampleBufferGetImageBuffer(sample)) {
                ++videoCalls;
                // No persistent video attachment: capture pipelines may reuse
                // CMSampleBuffer/attachment storage for the next real frame.
                // The thread-local depth guard already handles nested hooks.
                if (OBEnabled()) {
                    if (OBReplaceVideo(sample)) {
                        original(self, cmd, sample); ++replaced; failure = 0; return;
                    }
                    failure = 3;
                }
            } else if (type == kCMMediaType_Audio) {
                ++audioCalls;
                if (OBEnabled() && !CMGetAttachment(sample, CFSTR("local.xiaoguai.obsbridge.mixed"), nullptr)) {
                    CMSampleBufferRef result = OBCopyAudioForNode(sample, self);
                    if (result) {
                        @try { original(self, cmd, result); ++mixed; failure = 0; }
                        @finally { CFRelease(result); }
                        return;
                    }
                    failure = 5;
                }
            }
            original(self, cmd, sample);
        }
    } @finally { --depth; }
}
template<size_t... Slots> auto replacements(std::index_sequence<Slots...>) {
    return std::array<IMP, sizeof...(Slots)>{(IMP)emit<Slots>...};
}

bool compatible(Method method) {
    if (!method || method_getNumberOfArguments(method) != 3) return false;
    char type[256]{};
    method_getReturnType(method, type, sizeof(type)); if (strcmp(type, "v")) return false;
    method_getArgumentType(method, 0, type, sizeof(type)); if (type[0] != '@') return false;
    method_getArgumentType(method, 1, type, sizeof(type)); if (type[0] != ':') return false;
    method_getArgumentType(method, 2, type, sizeof(type));
    return type[0] == '^' && strstr(type, "CMSampleBuffer");
}
Method directMethod(Class cls, SEL selector) {
    unsigned count = 0; Method found = nullptr;
    Method *methods = class_copyMethodList(cls, &count);
    for (unsigned i = 0; i < count; ++i) if (method_getName(methods[i]) == selector) { found = methods[i]; break; }
    free(methods); return found;
}
bool subclass(Class cls, Class base) {
    for (Class current = cls; current; current = class_getSuperclass(current)) if (current == base) return true;
    return false;
}
void install(Class cls, SEL selector, bool inherited) {
    unsigned count = hookCount.load();
    for (unsigned i = 0; i < count; ++i) if (hooks[i].cls == cls) return;
    Method method = inherited ? class_getInstanceMethod(cls, selector) : directMethod(cls, selector);
    if (!method) return;
    if (!compatible(method)) {
        NSLog(@"[OBSBridge] rejected %@ emitSampleBuffer: signature %s", NSStringFromClass(cls), method_getTypeEncoding(method));
        return;
    }
    if (count >= MaximumHooks) return;
    hooks[count].cls = cls;
    Emit fallback = (Emit)method_getImplementation(method), original = nullptr;
    hooks[count].original.store(fallback, std::memory_order_release);
    static const auto wrappers = replacements(std::make_index_sequence<MaximumHooks>{});
    MSHookMessageEx(cls, selector, wrappers[count], (IMP *)&original);
    hooks[count].original.store(original ?: fallback, std::memory_order_release);
    hookCount.store(count + 1, std::memory_order_release);
    NSLog(@"[OBSBridge] installed BWNodeOutput boundary on %@", NSStringFromClass(cls));
}
void scan(void) {
    @autoreleasepool {
        Class base = objc_getClass("BWNodeOutput");
        SEL selector = sel_registerName("emitSampleBuffer:");
        if (base) {
            install(base, selector, true);
            int capacity = objc_getClassList(nullptr, 0);
            if (capacity > 0 && capacity < 100000) {
                auto *list = static_cast<Class __unsafe_unretained *>(calloc(size_t(capacity), sizeof(Class)));
                if (list) {
                    int count = std::min(capacity, objc_getClassList(list, capacity));
                    for (int i = 0; i < count; ++i) if (list[i] != base && subclass(list[i], base)) install(list[i], selector, false);
                    free(list);
                }
            }
        }
        if (!hookCount.load()) failure = 1;
    }
}
void imageLoaded(const mach_header *, intptr_t) {
    if (!checkQueue || queued.exchange(true)) return;
    dispatch_async(checkQueue, ^{ queued = false; scan(); });
}
}

__attribute__((constructor)) static void OBMediaInitialize(void) {
    // Health signal first: reports module execution without preferences writes.
    OBMediaHeartbeat(0, 0, 0, 0, 0, 1);
    NSLog(@"[OBSBridge] %@ mediaserverd module entered", OB_VERSION);
    checkQueue = dispatch_queue_create("local.xiaoguai.obsbridge.media.check", DISPATCH_QUEUE_SERIAL);
    _dyld_register_func_for_add_image(imageLoaded);
    dispatch_async(checkQueue, ^{ scan(); });
    healthTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, checkQueue);
    dispatch_source_set_timer(healthTimer, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC),
                              NSEC_PER_SEC, NSEC_PER_SEC / 10);
    dispatch_source_set_event_handler(healthTimer, ^{
        @autoreleasepool {
            static unsigned ticks = 0;
            if (!hookCount.load() || ++ticks % 5 == 0) scan();
            auto bus = OBBusConsumer();
            OBRequestMediaReadAccess(); // background permission queue; never block emitSampleBuffer:
            OBPublishAudioDiagnostics(); // compact metadata/error codes only; never audio content
            uint32_t result = failure.load();
            if (!bus && hookCount.load()) result = 2;
            OBMediaHeartbeat(hookCount.load(), videoCalls.load(), audioCalls.load(),
                replaced.load(), mixed.load(), result);
        }
    });
    dispatch_resume(healthTimer);
}
